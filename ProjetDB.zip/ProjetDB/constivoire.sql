-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 25 avr. 2019 à 22:32
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `constivoire`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `pseudo` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `sexe` varchar(20) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_message` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `pseudo`, `phone`, `sexe`, `ville`, `password`, `id_message`) VALUES
(12, 'Dani', 'Winner', 'DWinner00', 55052013, 'homme', 'yamoussokro', '264fbe40fa0a125ac1529b447b71cabc95dc5814', 0),
(13, 'Dani', 'Winner', 'DWinner5500', 55052013, 'homme', 'yamoussokro', 'd9356364d3d231b496128df4f190d05d7f424161', 0),
(15, 'Daniel', 'Winner', 'DWinner5500', 55052013, 'homme', 'yamoussokro', '6d04a668ccc2166d714a086df60aca8082ed8667', 0),
(16, 'Lucas', 'bgt', 'lucas@gmail.com', 55052013, 'homme', 'abidjan', '6d04a668ccc2166d714a086df60aca8082ed8667', 0);

-- --------------------------------------------------------

--
-- Structure de la table `entrprises`
--

CREATE TABLE `entrprises` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `secteur_activit` varchar(100) NOT NULL,
  `description` varchar(300) NOT NULL,
  `numero` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_message` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `entrprises`
--

INSERT INTO `entrprises` (`id`, `nom`, `email`, `ville`, `adresse`, `secteur_activit`, `description`, `numero`, `password`, `id_message`) VALUES
(1, 'bativoire', 'bativoire@gmail.com', 'abidjan', 'yopougon rue princesse', 'Travaux publics', 'nous sommes specialis&eacute; dans les travaux publics', 3451200, '73ee4958bdb5a056029ebd39b8abbaa3dbc0f333', 0),
(3, 'GEBAT', 'gebat@gmail.com', 'abidjan', 'Angr&eacute; 7 &egrave;me tranche Cocody, Abidjan, Cote D\'Ivoire', 'Batiment', 'Entreprise de construction &agrave; Abidjan, C&ocirc;te d\'Ivoire.', 22450381, 'a164dc1566a15a53bed0574050d61828db836796', 0),
(4, 'abidjanBat', 'abidjanBat@gmail.com', 'abidjan', 'angr&eacute; chateau', 'Ascenseur', 'une entreprise specialis&eacute; dans l\'installation d\'ascenseur', 21024580, '6d04a668ccc2166d714a086df60aca8082ed8667', 0),
(5, 'batci', 'batci@gmail.com', 'dimbokro', 'rue 180', 'Adduction', 'Nous sommes une entreprise d\'adduction d\'eau', 22456872, '6d04a668ccc2166d714a086df60aca8082ed8667', 0);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `id_client` int(11) NOT NULL,
  `id_entreprise` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `photo_entreprise`
--

CREATE TABLE `photo_entreprise` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `id_entreprise` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `video_entreprise`
--

CREATE TABLE `video_entreprise` (
  `id` int(11) NOT NULL,
  `nom` int(11) NOT NULL,
  `id_entreprise` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_message` (`id_message`);

--
-- Index pour la table `entrprises`
--
ALTER TABLE `entrprises`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_client` (`id_client`),
  ADD KEY `id_entreprise` (`id_entreprise`);

--
-- Index pour la table `photo_entreprise`
--
ALTER TABLE `photo_entreprise`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_entreprise` (`id_entreprise`);

--
-- Index pour la table `video_entreprise`
--
ALTER TABLE `video_entreprise`
  ADD KEY `id_entreprise` (`id_entreprise`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `entrprises`
--
ALTER TABLE `entrprises`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `photo_entreprise`
--
ALTER TABLE `photo_entreprise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`id_entreprise`) REFERENCES `entrprises` (`id`);

--
-- Contraintes pour la table `photo_entreprise`
--
ALTER TABLE `photo_entreprise`
  ADD CONSTRAINT `photo_entreprise_ibfk_1` FOREIGN KEY (`id_entreprise`) REFERENCES `entrprises` (`id`);

--
-- Contraintes pour la table `video_entreprise`
--
ALTER TABLE `video_entreprise`
  ADD CONSTRAINT `video_entreprise_ibfk_1` FOREIGN KEY (`id_entreprise`) REFERENCES `entrprises` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
