

<!-- page footer -->
  <footer>
    <div class="container-fluid">
      <div class="pt-4 pr-4 pl-4 d-flex justify-content-center">
        <p id="copyright"> Copyright 2019. </p>
      </div>
    </div>
  </footer>
  
  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  </div>
</body>

</html>