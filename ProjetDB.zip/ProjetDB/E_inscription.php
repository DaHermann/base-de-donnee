<?php 
session_start();
?>
<?php 
 require('databaseConnect.php'); 
?>

<?php

$nomEnt = $emailEnt = $villeEnt = $adresseEnt = $secteurAct = $descriptionEnt = $numero = $password= $password_conf = $erreur = "";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nomEnt = secure($_POST['nomEnt']);
    $emailEnt = secure($_POST['emailEnt']);
    $villeEnt = secure($_POST['villeEnt']);
    $adresseEnt = secure($_POST['adresseEnt']);
    $secteurAct = secure($_POST['secteurAct']);
    $descriptionEnt = secure($_POST['descriptionEnt']);
    $numero = secure($_POST['numero']);
    $password= secure($_POST['password']);
    $password_conf = secure($_POST['password_conf']);
    $erreur = "";
    
    if (!setpost($nomEnt) || !setpost($emailEnt) || !setpost($villeEnt) || !setpost($adresseEnt) || !setpost($secteurAct) || !setpost($descriptionEnt) || !setpost($numero) || !setpost($password) || !setpost($password_conf)) {
     
      $erreur = " Tous les champs doivent être obligatoirement remplis !";

    }elseif ($password != $password_conf) {

        $erreur = "Les mots de passe ne correspondent pas !";

      }else {
      $erreur = "";
     // insertion dans la base de donneee
      $insert = $db->prepare("INSERT INTO entrprises (`nom`, `email`, `ville`, `adresse`, `secteur_activit`, `description`, `numero`, `password`) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ");
      $password = sha1($password);
      $insert->bindParam(1, $nomEnt);   
      $insert->bindParam(2, $emailEnt);
      $insert->bindParam(3, $villeEnt);
      $insert->bindParam(4, $adresseEnt);
      $insert->bindParam(5, $secteurAct);
      $insert->bindParam(6, $descriptionEnt);
      $insert->bindParam(7, $numero);
      $insert->bindParam(8, $password);
      $insert->execute();

      header('location:E_connexion.php');
    }
  }

?>


<?php require('begin.php') ?>
  <title>Inscription Entreprise</title>
  <?php require('middle.php') ?>
  <?php require('headerCon_Ins.php') ?>
 <!-- formulaire d'inscription-->
 <section id="formulaire-inscription">

  <div class="card z-depth-4" style=" background-color: white !important;">
    <div class="card-body animated zoomIn slower">
      <form method="POST" action="">
        <div class="row justify-content-center">
          <!-- entête de formulaire-->
          <div class="formHeader col-sm-12"><p> Enregistrement d'entreprise</p></div>

          <!-- nom engreprise-->
          <div class="form-group input-group-lg  col-sm-6">
            <input type="text" class="form-control" name="nomEnt" placeholder="Nom de l'Entreprise...">
          </div>

          <!-- Email de l'entreprise-->
          <div class="form-group input-group-lg col-sm-7">
            <input type="email" class="form-control" name="emailEnt" placeholder="Email de l'entreprise...">
          </div>

          <!-- ville -->
          <div class="form-group input-group-lg col-sm-8">
            <select name="villeEnt"  class="browser-default custom-select custom-select-lg">
              <option value="null" class="active">Ville...</option>
              <option value="abidjan">Abidjan</option>
              <option value="yamoussokro">Yamoussokro</option>
              <option value="daloa">Daloa</option>
              <option value="dimbokro">Dimbokro</option>
              <option value="lacota">Lacota</option>
              <option value="agboville">Agboville</option>
            </select>
          </div>

          <!-- Adresse de l'entreprise-->
          <div class="form-group input-group-lg col-sm-9 ">
            <input type="text" class="form-control" name="adresseEnt" placeholder="Adresse de l'entreprise...">
          </div>

          <!-- secteur d'activité de l'entreprise-->
          <div class="form-group input-group-lg col-sm-10">
              <select name="secteurAct" class="browser-default custom-select custom-select-lg">
                <option value="null" class="active">Spécialisté...</option>
                <option value="Batiment">Batiment</option>
                <option value="Traveaux public">Travaux publics</option>
                <option value="Asscensenseur">Asscensenseur</option>
                <option value="Betion">Betion</option>
                <option value="Bois">Bois</option>
                <option value="Adduction">Adduction d'eau</option>
              </select>
            </div>

          <!-- Description de l'entreprise-->
          <div class="form-group blue-border-focus col-sm-9">
              <textarea class="form-control" name="descriptionEnt" rows="3" placeholder="Description le l'entreprise..."></textarea>
          </div>
          
          <!-- Numero -->
          <div class="form-group col-sm-10 input-group-lg">
            <input type="text" class="form-control" name="numero" placeholder="Telephne... ">
          </div>

          <!-- mot de passse-->
          <div class="form-group col-sm-11 input-group-lg">
              <input type="password" class="form-control" name="password" placeholder="Confirmez...">
          </div>
    
            <!-- validation de mot de passse-->
          <div class="form-group col-sm-12 input-group-lg">
            <input type="password" class="form-control" name="password_conf" placeholder="Confirmez...">
          </div>

            <!-- bouton submit-->
          <button type="submit" class="btn btn-primary col-sm-8 mt-4 animated slideInRight slower" name="inscrire">Enregister</button>
  
        <div class="form-group col-sm-6">
            <p class="erreur animated flipInX infinite slower"><?php echo $erreur; ?></p>
        </div>
      </form>
    </div>
  </div>

</section>
  <?php require('footer&End.php') ?>
