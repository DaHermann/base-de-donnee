</head>
<body style="background: url('img/workers.jpg');">
<div style="background-color: rgba(250, 100, 20, 0.6) ">
  
 