<?php

   $server = "localhost";
   $dbName = "constivoire";
   $user = "hardworkers";
   $password = "constivoire";  
   
   try{
      $db = new PDO("mysql:host=$server;dbname=$dbName", $user, $password);
      $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   }
   catch(Exception $e){
      die('Echec de connexion à la base de donnée'.$e->getMessage());
   }

   function secure($n){
      $n = trim($n);
      $n = htmlspecialchars($n);
      $n = htmlentities($n);
      return $n;
     }

   function setpost($m){
      $m = isset($m) && !empty($m);
      return $m;
   }

?>
