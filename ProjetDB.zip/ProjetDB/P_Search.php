<?php 
$recherche = $erreur = "";

if (isset($_GET['domaine']) && $_GET['domaine']!="choisir...") {
  
  $recherche = secure($_GET['domaine']);

  $sql = $db->query("SELECT secteur_activit FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");

		if ($sql->rowCount() > 0) {
     
      $sql_nom = $db->query("SELECT nom FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");
      $sql_email = $db->query("SELECT email FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");
      $sql_adresse = $db->query("SELECT adresse FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");
      $sql_numero = $db->query("SELECT numero FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");
      $sql_description = $db->query("SELECT description FROM entrprises WHERE secteur_activit LIKE '%$recherche%' ");

      $data = $sql->fetch();
      $data_sql_nom = $sql_nom->fetch();
      $data_sql_email = $sql_email->fetch();
      $data_sql_adresse = $sql_adresse->fetch();
      $data_sql_numero = $sql_numero->fetch();
      $data_sql_description = $sql_description->fetch();

		} 
	}
?>