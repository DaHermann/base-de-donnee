<?php 
session_start();
?>

<?php 
require('databaseConnect.php'); 
?>

<?php

$nom = $prenom = $pseudo = $phone = $sexe = $ville = $password = $password_conf = $erreur = "";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nom = secure($_POST['nom']);
    $prenom = secure($_POST['prenom']);
    $pseudo = secure($_POST['pseudo']);
    $phone = secure($_POST['phone']);
    $sexe = $_POST['sexe'];
    $ville = secure($_POST['ville']);
    $password = secure($_POST['password']);
    $password_conf = secure($_POST['password_conf']);
    $erreur = "";
    
    if (!setpost($nom) || !setpost($prenom) || !setpost($pseudo) || !setpost($phone) || !setpost($sexe) || !setpost($ville) || !setpost($password) || !setpost($password_conf)) {
     
      $erreur = " Tous les champs doivent être obligatoirement remplis !";
    }elseif ($password != $password_conf) {
        $erreur = "Les mots de passe ne correspondent pas !";
      }else {
      $erreur = "";
      $insert = $db->prepare("INSERT INTO client ( `nom`, `prenom`, `pseudo`, `phone`, `sexe`, `ville`, `password`) VALUES(?, ?, ?, ?, ?, ?, ?) ");  
      $insert->bindParam(1, $nom);   
      $insert->bindParam(2, $prenom);
      $insert->bindParam(3, $pseudo);
      $insert->bindParam(4, $phone);
      $insert->bindParam(5, $sexe);
      $insert->bindParam(6, $ville);
      $insert->bindParam(7, sha1($password));

      $insert->execute();
      $_SESSION['prenom'] = $prenom;
      $_SESSION['nom'] = $nom;
      $_SESSION['pseudo'] = $pseudo;

      header('location:C_connexion.php');
    }
  }

?>


<?php require('begin.php'); ?>
<title>Inscription Client</title>
<?php require('middle.php'); ?>
<?php require('headerCon_Ins.php'); ?>
  <!-- formulaire d'inscription-->
  <div class="container" >
  <section id="formulaire-inscription">
    <div class="card z-depth-4" style=" background-color: white !important;">
      <div class="card-body animated zoomIn slower">
        <form method="POST" action="">
          <div class="row justify-content-center">
            <!-- entête de formulaire-->
            <div class="formHeader col-sm-12"><p> Inscription Client</p></div>
  
            <!-- nom-->
            <div class="form-group col-sm-6 input-group-lg">
              <input type="text" class="form-control" name="nom" placeholder="Nom...">
            </div>
            <!-- prenom-->
            <div class="form-group col-sm-7 input-group-lg">
              <input type="text" class="form-control" name="prenom" placeholder="Prenom...">
            </div>
            <!-- pseudo-->
            <div class="form-group col-sm-8 input-group-lg">
              <input type="text" class="form-control" name="pseudo" placeholder="Pseudo...">
            </div>
            <!-- telephone-->
            <div class="form-group col-sm-9 input-group-lg">
              <input type="text" class="form-control" name="phone" placeholder="Numero de telephone...">
            </div>
            <!-- sexe -->  
            <div class="form-group col-sm-8 d-flex justify-content-center">
                <div class="form-check-inline mr-4 ml-5">
                    <label class="form-check-label">
                      <input type="radio" class="form-check-input" value="homme" name="sexe" checked>Homme
                    </label>
                  </div>
                  <div class="form-check-inline mr-5 ml-4">
                    <label class="form-check-label">
                      <input type="radio" class="form-check-input" value="femme" name="sexe">Femme
                    </label>
                  </div>
            </div>
            <!-- ville -->
            <div class="form-group col-sm-10 input-group-lg">
              <select name="ville" id="" class="browser-default custom-select custom-select-lg">
                <option value="" class="active">Ville...</option>
                <option value="abidjan">Abidjan</option>
                <option value="yamoussokro">Yamoussokro</option>
                <option value="daloa">Daloa</option>
                <option value="dimbokro">Dimbokro</option>
                <option value="lacota">Lacota</option>
                <option value="agboville">Agboville</option>
              </select>
            </div>
            <!-- mot de passe -->
            <div class="form-group col-sm-11 input-group-lg">
              <input type="password" class="form-control" name="password" placeholder="Mot de passe... ">
            </div>
              <!-- validation de mot de passse-->
            <div class="form-group col-sm-12 input-group-lg">
                <input type="password" class="form-control" name="password_conf" placeholder="Confirmez...">
              </div>
              <!-- bouton submit-->
            <button type="submit" class="btn btn-primary col-sm-8 mt-4 animated slideInRight slower" name="inscrire" data-toggle="modal" data-target="#modalCookie1">S'inscrire</button>
    
          <div class="form-group col-sm-6 mt-4">
              <p class="erreur animated flipInX infinite slower"> <?php echo $erreur ;?> </p>
          </div>
        </form>
      </div>
    </div>
  </section>
  </div>

    <?php require('footer&End.php'); ?>