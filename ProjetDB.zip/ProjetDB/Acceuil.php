<?php require('begin.php') ?>
  <title>Acceuil</title>
  <?php require('middle.php') ?>
  <?php require('headerNotC.php') ?>

  <div class="container-fluid">
    <!-- a propos de nous -->
    <section class="mt-5 mb-5 mr-4 ml-4 pt-4 pb-4 pr-4 pl-4 z-depth-2" id="about" style=" background-color: white !important;">
        <h3 class="section_header"> à propos de nous </h3>
        <div class="divider"></div>    
      <div class="row d-flex justify-content-center">
        <div class="col-sm-12 col-md-4 mt-4 mb-4 animated animated-easeOutQuad">
          <p> <img src="img/webp/basket-6x.webp" alt="icon" class="bigIcon"></p>
          <p>
            * Nous sommes une entreprise qui vous propose des entreprise de construiction.
          </p>
        </div>
        <div class="col-sm-12 col-md-4 mt-4 mb-4">
        <p> <img src="img/briefcase-6x.png" alt="icon" class="bigIcon"></p>
          <p>
            *Des entrepises fiables et à la hauteur de vos tâches.
          </p>
        </div>
        <div class="col-sm-12 col-md-4 mt-4 mb-4">
        <p> <img src="img/basket-8x.png" alt="icon" class="bigIcon"></p>
          <p>
            * Parce-que nous pensons à vous notre objectif est de vous facilité la tâches, <br>
              vous permettre de choisir parmis une liste infinie ceux qui conrespond à vos besoin.
          </p>
        </div>
      </div>
    </section>

    <!-- comment ça marche -->
    <section class="mt-5 mb-5 mr-4 ml-4 pt-4 pb-4 pr-4 pl-4 z-depth-2" id="how" style=" background-color: white !important;"> 
      <h3 class="col-sm-12 section_header">Comment ça marche</h3>
      <div class="divider"></div> 
      <div class="row d-flex justify-content-center">
        <div class="col-sm-12 mt-4 mb-4">
          <p>
            * l'utilisation est tes simple, connecter vous au site faite vos recherche à travers l'option selection du domaine. <br>
              Une fois le domaine selectionné cliquer sur le bouton recherche pour avoir votre liste a l'ecran et contacter l'entrepise.

          </p>
        </div>
      </div>
    </section>
  </div>
  
  <?php require('footer&End.php') ?>