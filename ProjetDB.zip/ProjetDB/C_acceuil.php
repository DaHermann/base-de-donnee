<?php 
session_start();
?>
<?php require('databaseConnect.php'); ?>
<?php require('P_Search.php'); ?>

<?php require('begin.php'); ?>
<title>Acceuil Client</title>
<?php require('middle.php'); ?>
<?php 
require('headerC_C.php'); 
?>

   <!-- a propos de nous -->

    <?php if (!isset($_GET['domaine'])): ?>

    <section class="mt-5 mb-5 mr-4 ml-4 pt-4 pb-4 pr-4 pl-4 z-depth-2" id="about" style=" background-color: white !important;">
        <h3 class="section_header"> à propos de nous </h3>
        <div class="divider"></div>    
      <div class="row d-flex justify-content-center">
        <div class="col-sm-12 col-md-4 mt-4 mb-4 animated animated-easeOutQuad">
          <p> <img src="img/webp/basket-6x.webp" alt="icon" class="bigIcon"></p>
          <p>
            * Nous sommes une entreprise qui vous propose des entreprises de construiction.
          </p>
        </div>
        <div class="col-sm-12 col-md-4 mt-4 mb-4">
        <p> <img src="img/briefcase-6x.png" alt="icon" class="bigIcon"></p>
          <p>
            *Des entrepises fiables et à la hauteur de vos tâches.
          </p>
        </div>
        <div class="col-sm-12 col-md-4 mt-4 mb-4">
        <p> <img src="img/basket-8x.png" alt="icon" class="bigIcon"></p>
          <p>
            * Parce-que nous pensons à vous notre objectif est de vous faciliter la tâche, <br>
              vous permettre de choisir parmis une liste infinie ceux qui conrespond à vos besoind.
          </p>
        </div>
      </div>
    </section>

    <!-- comment ça marche -->
    <section class="mt-5 mb-5 mr-4 ml-4 pt-4 pb-4 pr-4 pl-4 z-depth-2" id="how" style=" background-color: white !important;"> 
      <h3 class="col-sm-12 section_header">Comment ça marche</h3>
      <div class="divider"></div> 
      <div class="row d-flex justify-content-center">
        <div class="col-sm-12 mt-4 mb-4">
          <p>
            * l'utilisation est tes simple, connecter vous au site faite vos recherche à travers l'option selection du domaine. <br>
              Une fois le domaine selectionné cliquer sur le bouton recherche pour avoir votre liste à l'ecran et contacter l'entrepise.

          </p>
        </div>
      </div>
    </section>
  <?php endif;?>
  <?php if ($recherche): ?>
    <?php for($i = $sql->rowCount(); $i > 0; $i--):?>
    <?php 
     $domaine = $data['secteur_activit'];
     $nom = $data_sql_nom['nom'];
     $email = $data_sql_email['email'];
     $adresse = $data_sql_adresse['adresse'];
     $numero = $data_sql_numero['numero'];
     $description = $data_sql_description['description'];

     $_SESSION['Domaine'] = "$domaine";
     $_SESSION['Nom'] = "$nom";
     $_SESSION['Email'] = "$email";
     $_SESSION['Adresse'] = "$adresse";
     $_SESSION['Numero'] = "$numero";
     $_SESSION['Description'] = "$description";

    ?>
      <section id="result" class="mr-5 ml-5 mt-5 mb-5" >
        <!-- Card -->
        <div class="card  mt-5 mb-5">
          <div class="card-body mr-2 ml-2">
            <!-- image de l'entreprise -->
            <div class="row z-depth-4 d-flex justify-content-center" style=" background-color: white !important;">
              <div class="E_image col-sm-4 mr-3 ml-3 mt-3 mb-3" style="height: 200px; border: 2px solid black;">
                <h3> Image </h3>
              </div>
            <!-- nom numero et adresse -->
              <div class="Detail_Ent col-sm-5 mr-3 ml-3 mt-5 mb-3">
                <p><i>Domaine :  </i><?php echo $domaine;?></p>
                <p><i>Nom :</i>  <?php echo $nom;?></p>
                <p><i>Email :</i>  <?php echo $email;?></p>
                <p><i>Adresse :</i>  <?php echo $adresse;?></p>
                <p><i>Telephone :</i>  <?php echo $numero;?></p>
              </div>
              <a href="C_afficherEnt.php" class="btn btn-default col-sm-6 mt-3 mb-3">Plus...</a>
            </div>
          </div>  
        </div>
        <!-- / card -->
        </div>
      </section>
    <?php endfor;?>
    <?php endif;?>
<?php require('footer&End.php') ?>