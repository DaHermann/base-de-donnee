<div style="background-image: url(img/img1.jpg);">
  <header class="acceuil" style=" background-color: rgba(33, 98, 13, 0.7) !important;">
      <div class="container-fluid pr-4 pl-4">
        <!--Navbar -->
      <nav class="navbar navbar-expand-lg bg-faded" style="box-shadow: none;">
        <!--Navbar -->
          <a class="navbar-brand logo" href="Acceuil.php"><span class="first_letter">C</span>onst<span class="first_letter">I</span>voire<span class="">.</span></a>
          <button class="navbar-toggler first-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
            aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon "><img src="img/grid-three-up-6x.png" alt=""></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item"><a class="nav-link" href="Acceuil.php">Retour</a></li>
            </ul>
          </div>
        </nav>
        <!--/.Navbar -->
  </header>

</div>