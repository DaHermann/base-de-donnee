<?php require('begin.php') ?>
  <title>Ajouter/ modifier photo</title>
  <?php require('middle.php') ?>
  <?php require('headerC_Ent.php') ?>

  <section class="m-5">
    <!-- ajout de photo -->
      <div class="card m-5">
        <div class="card-body">
          <div class=" row d-flex justify-content-center m5">
           <div class="col-sm-12">
              <form method="GET" class="z-depth-4 p-5" style=" background-color: white !important;">
                <h4 class="formHeader  mt-3 mb-3">Ajouter / modifier la Photo</h4>
                <div class="divider"></div>
                <div class="row d-flex justify-content-center">
                  <div class="form-group col-md-6  mt-3 mb-3" style="height:200px; border: 1px solid black;"></div>
                  <!-- input de type file-->
                  <div class="form-group col-md-6 mt-3 mb-3 video"> <span class="glyphicon glyphicon-search"></span><input type="file" name="photo"></div>               
                  <button type="submit" class="col-md-6 btn-success mt-3 mb-3 btn-lg">Ajouter / modifier </button>
                </div>
              </form>
           </div>
          </div>
        </div>
      </div>
    </section>

    <?php require('footer&End.php') ?>