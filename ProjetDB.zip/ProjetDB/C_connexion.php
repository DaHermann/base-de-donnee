<?php 
session_start(); 
?>
<?php 
require('databaseConnect.php'); 
?>
<?php

 $pseudo = $password = $erreur = "";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $pseudo = secure($_POST['pseudo']);
    $password = sha1(secure($_POST['password']));
    $erreur = "";
    
    if (!setpost($pseudo) || !setpost($password)) {
     
      $erreur = " * Pseudo / mot de passe incorrect ! ";

    }else {
      // verification de l'existance dans la base de donnee
        $sql = $db->query("SELECT pseudo FROM client WHERE password = '$password' && pseudo = '$pseudo' ");
      
          if ($sql->rowCount() != 0) {
           // selection du nom et du pseudo present dans la base de donnee
            $sql_nom = $db->query("SELECT nom FROM client WHERE pseudo = '$pseudo' ");
            $sql_pseudo = $db->query("SELECT pseudo FROM client WHERE pseudo = '$pseudo' ");
      //affichage de la selection dans la base de donnee
            $data_sql_pseudo = $sql_pseudo->fetch();
            $data_sql_nom = $sql_nom->fetch();
      //affectation des donnee à la variable de section
          $_SESSION['pseudo']= $data_sql_pseudo['pseudo'];
          $_SESSION['nom']= $data_sql_nom['nom'];

          header('location:C_acceuil.php');

          }else {
          $erreur = " * Pseudo / mot de passe incorrect ! ";
        }
      
        
      }
      // else {
      //   $insert = $db->prepare("SELECT nom FROM client WHERE pseudo = ? AND password = ?)");
      //   $insert->bindParam(1, $pseudo);
      //   $_SESSION['pseudo'] = $insert->fetch(pseudo);
      //   $_SESSION['nom'] = $insert->fetch(nom);
      //   $_SESSION['prenom'] = $insert->fetch(prenom);
      //   header('location:C_acceuil.php');

      // }
    }

?>



  <?php require('begin.php'); ?>
  <title>Connexion Client</title>
  <?php require('middle.php'); ?>
  <?php require('headerCon_Ins.php'); ?>

  <!-- formulaire de connextion client-->
  <div class="container pr-4 pl-4">
    <section id="formulaire-connextion">
    <div class="card z-depth-4" style=" background-color: white !important;">
      <div class="card-body p5 animated zoomIn slow">
          <form method="POST" action="" class="p5">
            <div class="row justify-content-center">
                <!-- connexion client -->
              <div class="formHeader col-sm-12"><p>Connexion client</p></div>
              <!-- pseudo-->
              <div class="md-form col-sm-8 ">
                <input type="text" class="form-control" id="pseudo" name="pseudo">
                <label for="pseudo">Pseudo...</label>
              </div>
              
              <!-- mot de passe -->
              <div class="md-form col-sm-11">
              <input type="password" class="form-control " id="password" name="password">
                <label for="password">Mot de passe ...</label>
              </div>
                
                <!-- bouton submit-->
              <button type="submit" class="btn btn-primary col-sm-8 mt-4 animated slideInRight slower"  name="connexion" >Se conecter</button>
      
            <div class="md-form col-sm-6">
                <p  class="erreur animated flipInX infinite slower" > <?php echo $erreur; ?> </p>
            </div>
          </form>
      </div>
    </div>
    </section>
  </div>
  <?php require('footer&End.php'); ?>