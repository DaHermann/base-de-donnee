<?php session_start();?>
<?php 
require('databaseConnect.php'); 
?>
<?php

 $email = $password = $erreur = "";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $email = secure($_POST['email']);
    $password = sha1(secure($_POST['password']));
    $erreur = "";
    
    if (!setpost($email ) || !setpost($password)) {
     
      $erreur = " * Email / mot de passe incorrect ! ";

    }else {
      // verification de l'existance dans la base de donnee
        $sql = $db->query("SELECT email FROM entrprises WHERE password = '$password' && email = '$email' ");
      
          if ($sql->rowCount() != 0) {
           // selection du nom et de l'email present dans la base de donnee
            $sql_nom = $db->query("SELECT nom FROM entrprises WHERE email = '$email' ");
            $sql_email = $db->query("SELECT email FROM entrprises WHERE email = '$email' ");
      //affichage de la selection dans la base de donnee
            $data_sql_email = $sql_email->fetch();
            $data_sql_nom = $sql_nom->fetch();
      //affectation des donnee à la variable de section
          $_SESSION['email']= $data_sql_email['email'];
          $_SESSION['nom']= $data_sql_nom['nom'];
          header('location:E_acceuil.php');

          }else {
          $erreur = " * Email / mot de passe incorrect ! ";
        }
      
        
      }
  }
?>

<?php require('begin.php') ?>
  <title>Connexion Entreprise</title>
  <?php require('middle.php') ?>
  <?php require('headerCon_Ins.php') ?>


  <!-- formulaire de connextion Entreprise -->
  <section id="formulaire-connextion" class="container">

      <div class="card z-depth-4" style=" background-color: white !important;">
        <div class="card-body p5 animated zoomIn slower">
           <form method="POST" action="">
             <div class="row justify-content-center">
                 <!-- connexion client -->
               <div class="formHeader col-sm-12"><p>Connexion Entreprise</p></div>
               <!-- email-->
               <div class="md-form col-sm-8">
                 <input type="text" class="form-control" id="email" name="email">
                 <label for="email">Email...</label>
               </div>
               
               <!-- mot de passe -->
               <div class="md-form col-sm-11">
                 <input type="password" class="form-control" id="password" name="password">
                 <label for="password">Mot de passe...</label>
               </div>
                 
                 <!-- bouton submit-->
               <button type="submit" class="btn btn-primary col-sm-8 mt-4 animated slideInRight slower" name="inscrire">Se conecter</button>
       
             <div class="form-group col-sm-6">
                 <p class="erreur animated flipInX infinite slower"><?php echo $erreur; ?></p>
             </div>
           </form>
        </div>
      </div>
     </section>

     <?php require('footer&End.php') ?>