<?php require('begin.php') ?>
<title>Ajouter/ modifier photo</title>
<?php require('middle.php') ?>
<?php require('headerC_Ent.php') ?>
  <!-- a propos de nous -->
  
    <?php require('footer&End.php') ?>