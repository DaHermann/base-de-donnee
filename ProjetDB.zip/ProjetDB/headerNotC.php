<div style="background-image: url(img/img1.jpg);">
<header class="acceuil" style=" background-color: rgba(33, 98, 13, 0.7) !important;">
    <div class="container-fluid pr-4 pl-4">
      <!--Navbar -->
    <nav class="navbar navbar-expand-lg bg-faded" style="box-shadow: none;">
      <!--Navbar -->
        <a class="navbar-brand logo" href="Acceuil.php"><span class="first_letter">C</span>onst<span class="first_letter">I</span>voire<span class="">.</span></a>
        <button class="navbar-toggler first-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
          aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon "><img src="img/grid-three-up-6x.png" alt=""   width=30></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
          <ul class="navbar-nav ml-3">
              <li class="nav-item"><a href="Acceuil.php" class="nav-link float-left">Acceuil</a></li>
          </ul>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <!--liste deroulante de la barre de navigation -->
                <a class="nav-link dropdown-toggle" id="Entreprise_drop" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img src="img/icon/basket.svg" alt="icon" class="iconUser">Entreprise ?</a>
              <div class="dropdown-menu dropdown-menu-right dropdown-info" aria-labelledby="Entreprise_drop">
                <a class="dropdown-item" href="E_inscription.php">S'enregistrer</a>
                <a class="dropdown-item" href="E_connexion.php">Se connecter <img src="img/account-login-6x.png" width=15></a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="Client_drop" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img src="img/icon/person.svg" alt="icon" class="iconUser"> Profile </a>
              <div class="dropdown-menu dropdown-menu-right dropdown-info" aria-labelledby="Client_drop">
                <a class="dropdown-item" href="C_inscription.php">S'inscrire</a>
                <a class="dropdown-item" href="C_connexion.php">se connecter <img src="img/account-login-6x.png" width=15></a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
      <!--/.Navbar -->

      <!--Select Seach -->
      <div id="Search">
        <form class="row d-flex justify-content-center">
          <p class="col-sm-12 text-align-center">Commancer votre recherche</p>
          <div class="form col-md-4">
            <select name ="domaine" id="" class="custom-select custom-select-lg">
              <option value="choisir...">choisir...</option>
              <option value="Batiment">Batiment</option>
              <option value="Traveaux public">Travaux publics</option>
              <option value="Asscensenseur">Ascenseur</option>
              <option value="Betion">Beton</option>
              <option value="Bois">Bois</option>
              <option value="Adduction d'eau">Adduction d'eau</option>
            </select>
          </div>
          <button class="btn  col-md-2" type="submit"><i class="fas fa-send-o"></i> CHERCHER</button>
        </form>
      </div>
      <!-- /Select Seach -->
    </div>
  </header>
</div>