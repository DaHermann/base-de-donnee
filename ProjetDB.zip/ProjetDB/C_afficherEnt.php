<?php session_start(); ?>

<?php require('databaseConnect.php'); ?>
<?php require('P_Search.php'); ?>

<?php require('begin.php'); ?>
<title>Detail Entreprise</title>
<?php require('middle.php'); ?>
  <div  style="background-image: url(img/img1.jpg);">
  <header class="acceuil" style=" background-color: rgba(33, 98, 13, 0.7) !important;">
    <div class="container-fluid pr-4 pl-4">
      <!--Navbar -->
      <nav class="navbar navbar-expand-lg bg-faded" style="box-shadow: none;">
        <!--Navbar -->
          <a class="navbar-brand logo" href="C_acceuil.php"><span class="first_letter">C</span>onst<span class="first_letter">I</span>voire<span class="">.</span></a>
          <button class="navbar-toggler first-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
            aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon "><img src="img/grid-three-up-6x.png" alt=""  width=30></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
            <ul class="navbar-nav ml-3">
                <li class="nav-item"><a href="C_acceuil.php" class="nav-link float-left">Acceuil</a></li>
            </ul>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="Client_drop" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">
                  <img src="img/icon/person.svg" alt="icon" class="iconUser"><?php echo $_SESSION['nom'];?> </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-info" aria-labelledby="Client_drop">
                  <a class="dropdown-item" href="deconnection.php">Deconnexion <img src="img/account-logout-6x.png" width=15></a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
        <!--/.Navbar -->

        <!--Select Seach -->
        <div id="Search">
          
        </div>
        <!-- /Select Seach -->
      </div>
    </header>
  </div>

  <!-- affichage des detail de l'entreprise -->
  <section id="Affche_Ent" class="mr-5 ml-5 mt-5 mb-5" >
    <div class="card z-depth-4" style=" background-color: white !important;">
      <div class="card-body">
        <!-- image de l'entreprise -->
        <div class="row z-depth-4 d-flex justify-content-center" >
          <div class="E_image col-sm-3 mr-3 ml-3 mt-3 mb-3" style="height: 200px; border: 2px solid black;">
              <h3> Image </h3>
          </div>
          <!-- nom numero et adresse -->
          <div class="Detail_Ent col-sm-4 mr-3 ml-3 mt-5 mb-3">
            <p><i>Domaine : </i> <?php echo $_SESSION['Domaine'];?></p>
            <p><i>Nom :</i>  <?php echo $_SESSION['Nom'];?></p>
            <p><i>Email :</i>  <?php echo $_SESSION['Email'];?></p>
            <p><i>Adresse :</i>  <?php echo $_SESSION['Adresse'];?></p>
            <p><i>Telephone :</i>  <?php echo $_SESSION['Numero'];?></p>
          </div>
            <!-- video  -->
          <div class="col-sm-8 mr-3 ml-3 mt-3 mb-3" style="height: 200px; border: 2px solid black;">
            <div class="Video_Ent">
                <h3> Video </h3>
            </div>
          </div>
          <!-- description -->
          <div class="col-sm-8 mr-3 ml-3 mt-3 mb-3" >
            <div class="Description_Ent">
                <p><i><h4>Description :</h4></i> <h5><?php echo $_SESSION['Description'];?></h5></p>
            </div>
          </div>
          <!-- formulaire de contact -->
          <h4 class="contact col-sm-12" style="margin: 80px 40px auto; text-align: center;">Contact</h4>
          <div class="divider"></div>
          <div class="col-sm-12">
            <form action="" method="GET" class="row d-flex justify-content-center">
              <div class="col-sm-2 ml-2"><h3>Nom :</h3><?php echo $_SESSION['nom'];?></div>
              <div class="form-group blue-border-focus col-sm-9 mr-2">
                  <textarea class="form-control" name="descriptionEnt" rows="3" placeholder=" Votre message.."></textarea>
              </div>
                 <!-- bouton submit-->
                <button type="submit" class="btn btn-primary col-sm-8 mt-4 mb-3" name="inscrire">Envoyer</button>
            </form>
          </div>
        </div>
      </div>
    </div>  
  </section>

  <?php require('footer&End.php') ?>